import { MetadataRoute } from 'next';

export default function robots(): MetadataRoute.Robots {
    const baseUrl = 'https://testdone.in';

    return {
        rules: {
            userAgent: '*',
            allow: '/',
            disallow: [
                '/admin/',
                '/dashboard/',
                '/account/',
                '/questions/', // Private question bank
                '/login/',
                '/signup/',
                '/reset-password/',
                '/verify-email/',
            ],
        },
        sitemap: `${baseUrl}/sitemap.xml`,
    };
}
