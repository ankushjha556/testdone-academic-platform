'use client';

import { useAuth } from '@/contexts/AuthContext';
import { User, Lock, Mail, Save } from 'lucide-react';
import { useState } from 'react';

export default function SettingsPage() {
    const { user } = useAuth();
    const [loading, setLoading] = useState(false);

    return (
        <div className="min-h-screen py-8 bg-gray-50 dark:bg-gray-950">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="mb-8">
                    <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Account Settings</h1>
                    <p className="text-gray-600 dark:text-gray-400">Manage your profile and preferences.</p>
                </div>

                <div className="grid md:grid-cols-3 gap-8">
                    {/* Profile Card */}
                    <div className="card p-6 bg-white dark:bg-gray-900 shadow rounded-xl md:col-span-2">
                        <h2 className="text-lg font-semibold mb-6 flex items-center gap-2">
                            <User className="w-5 h-5 text-primary-600" />
                            Profile Information
                        </h2>

                        <div className="space-y-4">
                            <div className="grid md:grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">First Name</label>
                                    <input
                                        type="text"
                                        defaultValue={user?.firstName}
                                        className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 focus:ring-2 focus:ring-primary-500"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Last Name</label>
                                    <input
                                        type="text"
                                        defaultValue={user?.lastName}
                                        className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 focus:ring-2 focus:ring-primary-500"
                                    />
                                </div>
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Email Address</label>
                                <div className="relative">
                                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                    <input
                                        type="email"
                                        defaultValue={user?.email}
                                        disabled
                                        className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-gray-500 cursor-not-allowed"
                                    />
                                </div>
                                <p className="text-xs text-gray-500 mt-1">Email cannot be changed.</p>
                            </div>

                            <div className="border-t border-gray-200 dark:border-gray-700 pt-4 flex justify-end">
                                <button className="btn btn-primary flex items-center gap-2">
                                    <Save className="w-4 h-4" />
                                    Save Changes
                                </button>
                            </div>
                        </div>
                    </div>

                    {/* Security Card */}
                    <div className="card p-6 bg-white dark:bg-gray-900 shadow rounded-xl">
                        <h2 className="text-lg font-semibold mb-6 flex items-center gap-2">
                            <Lock className="w-5 h-5 text-primary-600" />
                            Security
                        </h2>

                        <div className="space-y-4">
                            <button className="w-full btn btn-outline justify-center">
                                Change Password
                            </button>
                            <button className="w-full btn btn-outline border-red-200 text-red-600 hover:bg-red-50 justify-center">
                                Delete Account
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
