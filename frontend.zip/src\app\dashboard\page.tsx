'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from 'next/navigation';
import { api } from '@/lib/api';
import {
    BookOpen,
    Clock,
    Target,
    TrendingUp,
    Award,
    ChevronRight,
    BarChart2,
    CheckCircle2,
    XCircle,
    Loader2,
    Calendar,
} from 'lucide-react';

interface DashboardStats {
    testsAttempted: number;
    questionsAttempted: number;
    averageScore: number;
    accuracy: number;
}

interface RecentAttempt {
    id: string;
    totalScore: number;
    correctCount: number;
    completedAt: string;
    test: {
        name: string;
        slug: string;
        totalMarks: number;
        exam: { name: string };
    };
}

export default function DashboardPage() {
    const { user, isLoading: authLoading } = useAuth();
    const router = useRouter();
    const [stats, setStats] = useState<DashboardStats | null>(null);
    const [recentAttempts, setRecentAttempts] = useState<RecentAttempt[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        if (!authLoading && !user) {
            router.push('/login');
            return;
        }
        if (user) {
            loadDashboardData();
        }
    }, [user, authLoading]);

    const loadDashboardData = async () => {
        try {
            const [analyticsRes, attemptsRes] = await Promise.all([
                api.get<{ summary: DashboardStats }>('/analytics'),
                api.get<{ attempts: RecentAttempt[] }>('/users/attempts?limit=5'),
            ]);

            if (analyticsRes.success) {
                setStats(analyticsRes.data?.summary || null);
            }
            if (attemptsRes.success) {
                setRecentAttempts(attemptsRes.data?.attempts || []);
            }
        } catch (error) {
            console.error('Failed to load dashboard:', error);
        } finally {
            setIsLoading(false);
        }
    };

    if (authLoading || isLoading) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <Loader2 className="w-8 h-8 animate-spin text-primary-600" />
            </div>
        );
    }

    return (
        <div className="min-h-screen py-8">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                {/* Welcome Section */}
                <div className="mb-8">
                    <h1 className="text-2xl sm:text-3xl font-bold font-heading text-gray-900 dark:text-white mb-2">
                        Welcome back, {user?.firstName}! 👋
                    </h1>
                    <p className="text-gray-600 dark:text-gray-400">
                        Continue your preparation journey. Here's your progress so far.
                    </p>
                </div>

                {/* Stats Cards */}
                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                    <div className="card p-5">
                        <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900/30 rounded-xl flex items-center justify-center">
                                <BookOpen className="w-6 h-6 text-primary-600" />
                            </div>
                            <div>
                                <p className="text-2xl font-bold text-gray-900 dark:text-white">
                                    {stats?.testsAttempted || 0}
                                </p>
                                <p className="text-sm text-gray-500">Tests Attempted</p>
                            </div>
                        </div>
                    </div>

                    <div className="card p-5">
                        <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-xl flex items-center justify-center">
                                <Target className="w-6 h-6 text-green-600" />
                            </div>
                            <div>
                                <p className="text-2xl font-bold text-gray-900 dark:text-white">
                                    {stats?.averageScore?.toFixed(1) || 0}%
                                </p>
                                <p className="text-sm text-gray-500">Average Score</p>
                            </div>
                        </div>
                    </div>

                    <div className="card p-5">
                        <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-amber-100 dark:bg-amber-900/30 rounded-xl flex items-center justify-center">
                                <TrendingUp className="w-6 h-6 text-amber-600" />
                            </div>
                            <div>
                                <p className="text-2xl font-bold text-gray-900 dark:text-white">
                                    {stats?.accuracy?.toFixed(1) || 0}%
                                </p>
                                <p className="text-sm text-gray-500">Accuracy</p>
                            </div>
                        </div>
                    </div>

                    <div className="card p-5">
                        <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 rounded-xl flex items-center justify-center">
                                <Award className="w-6 h-6 text-purple-600" />
                            </div>
                            <div>
                                <p className="text-2xl font-bold text-gray-900 dark:text-white">
                                    {stats?.questionsAttempted || 0}
                                </p>
                                <p className="text-sm text-gray-500">Questions Solved</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="grid lg:grid-cols-3 gap-8">
                    {/* Recent Tests */}
                    <div className="lg:col-span-2">
                        <div className="card">
                            <div className="p-5 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
                                <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                                    Recent Tests
                                </h2>
                                <Link
                                    href="/dashboard/tests"
                                    className="text-sm text-primary-600 hover:text-primary-700 flex items-center gap-1"
                                >
                                    View All
                                    <ChevronRight className="w-4 h-4" />
                                </Link>
                            </div>

                            <div className="p-5">
                                {recentAttempts.length > 0 ? (
                                    <div className="space-y-4">
                                        {recentAttempts.map((attempt) => (
                                            <Link
                                                key={attempt.id}
                                                href={`/tests/results/${attempt.id}`}
                                                className="flex items-center justify-between p-4 rounded-lg border border-gray-200 dark:border-gray-700 hover:border-primary-500 transition-colors group"
                                            >
                                                <div className="flex items-center gap-4">
                                                    <div className="w-10 h-10 bg-primary-100 dark:bg-primary-900/30 rounded-lg flex items-center justify-center">
                                                        <BookOpen className="w-5 h-5 text-primary-600" />
                                                    </div>
                                                    <div>
                                                        <h4 className="font-medium text-gray-900 dark:text-white">
                                                            {attempt.test.name}
                                                        </h4>
                                                        <p className="text-sm text-gray-500">
                                                            {attempt.test.exam.name} • {new Date(attempt.completedAt).toLocaleDateString()}
                                                        </p>
                                                    </div>
                                                </div>
                                                <div className="flex items-center gap-4">
                                                    <div className="text-right">
                                                        <p className="font-semibold text-gray-900 dark:text-white">
                                                            {attempt.totalScore}/{attempt.test.totalMarks}
                                                        </p>
                                                        <p className="text-sm text-gray-500">
                                                            {((attempt.totalScore / attempt.test.totalMarks) * 100).toFixed(1)}%
                                                        </p>
                                                    </div>
                                                    <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-primary-600" />
                                                </div>
                                            </Link>
                                        ))}
                                    </div>
                                ) : (
                                    <div className="text-center py-10">
                                        <BookOpen className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
                                        <p className="text-gray-500 dark:text-gray-400 mb-4">
                                            You haven't attempted any tests yet
                                        </p>
                                        <Link href="/tests" className="btn btn-primary btn-sm">
                                            Browse Mock Tests
                                        </Link>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Quick Actions */}
                    <div className="space-y-6">
                        <div className="card p-5">
                            <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                                Quick Actions
                            </h2>
                            <div className="space-y-3">
                                <Link
                                    href="/tests"
                                    className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                                >
                                    <div className="w-10 h-10 bg-primary-100 dark:bg-primary-900/30 rounded-lg flex items-center justify-center">
                                        <BookOpen className="w-5 h-5 text-primary-600" />
                                    </div>
                                    <div>
                                        <p className="font-medium text-gray-900 dark:text-white">Take a Mock Test</p>
                                        <p className="text-sm text-gray-500">Practice with real exam patterns</p>
                                    </div>
                                </Link>

                                <Link
                                    href="/questions"
                                    className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                                >
                                    <div className="w-10 h-10 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center">
                                        <Target className="w-5 h-5 text-green-600" />
                                    </div>
                                    <div>
                                        <p className="font-medium text-gray-900 dark:text-white">Practice Questions</p>
                                        <p className="text-sm text-gray-500">Topic-wise question practice</p>
                                    </div>
                                </Link>

                                <Link
                                    href="/dashboard/analytics"
                                    className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                                >
                                    <div className="w-10 h-10 bg-amber-100 dark:bg-amber-900/30 rounded-lg flex items-center justify-center">
                                        <BarChart2 className="w-5 h-5 text-amber-600" />
                                    </div>
                                    <div>
                                        <p className="font-medium text-gray-900 dark:text-white">View Analytics</p>
                                        <p className="text-sm text-gray-500">Track your progress</p>
                                    </div>
                                </Link>
                            </div>
                        </div>

                        {/* Upgrade Card */}
                        {user?.subscriptionStatus === 'free' && (
                            <div className="card p-5 bg-gradient-to-br from-primary-600 to-primary-800 text-white">
                                <h3 className="font-semibold text-lg mb-2">Upgrade to Premium</h3>
                                <p className="text-white/80 text-sm mb-4">
                                    Get access to all mock tests, detailed analytics, and premium features.
                                </p>
                                <Link href="/pricing" className="btn bg-white text-primary-700 hover:bg-gray-100 btn-sm">
                                    View Plans
                                </Link>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
