'use client';

import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import Link from 'next/link';
import { Plus, Search, Edit2, Trash2, BookOpen } from 'lucide-react';

export default function AdminExamsPage() {
    const [exams, setExams] = useState<any[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        loadExams();
    }, []);

    const loadExams = async () => {
        try {
            const res = await api.get<{ exams: any[] }>('/admin/exams');
            if (res.success) {
                setExams(res.data?.exams || []);
            }
        } catch (error) {
            console.error('Failed to load exams', error);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="p-8">
            <div className="flex justify-between items-center mb-8">
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Exams</h1>
                <Link href="/admin/exams/new" className="btn btn-primary flex items-center gap-2">
                    <Plus className="w-4 h-4" />
                    Add Exam
                </Link>
            </div>

            <div className="card bg-white dark:bg-gray-900 shadow rounded-lg overflow-hidden">
                <table className="w-full text-left">
                    <thead className="bg-gray-50 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
                        <tr>
                            <th className="px-6 py-3 text-sm font-medium text-gray-500">Name</th>
                            <th className="px-6 py-3 text-sm font-medium text-gray-500">Category</th>
                            <th className="px-6 py-3 text-sm font-medium text-gray-500">Status</th>
                            <th className="px-6 py-3 text-sm font-medium text-gray-500">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                        {isLoading ? (
                            <tr><td colSpan={4} className="p-6 text-center">Loading...</td></tr>
                        ) : exams.length === 0 ? (
                            <tr><td colSpan={4} className="p-6 text-center text-gray-500">No exams found.</td></tr>
                        ) : (
                            exams.map((exam) => (
                                <tr key={exam.id} className="hover:bg-gray-50 dark:hover:bg-gray-800">
                                    <td className="px-6 py-4">
                                        <div className="font-medium text-gray-900 dark:text-white">{exam.name}</div>
                                        <div className="text-xs text-gray-500">{exam.slug}</div>
                                    </td>
                                    <td className="px-6 py-4 text-gray-500">{exam.category?.name || '-'}</td>
                                    <td className="px-6 py-4">
                                        <span className="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-700">
                                            {exam.status}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 flex gap-2">
                                        <button className="p-1 hover:text-primary-600"><Edit2 className="w-4 h-4" /></button>
                                        <button className="p-1 hover:text-red-600"><Trash2 className="w-4 h-4" /></button>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
