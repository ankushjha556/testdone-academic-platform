'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { api } from '@/lib/api';
import { ChevronLeft, Save } from 'lucide-react';
import Link from 'next/link';

export default function CreateTestPage() {
    const router = useRouter();
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setTimeout(() => {
            setLoading(false);
            alert('Feature coming soon! Backend API integration required.');
            router.push('/admin/tests');
        }, 1000);
    };

    return (
        <div className="p-8">
            <Link href="/admin/tests" className="flex items-center gap-2 text-gray-500 hover:text-gray-900 mb-6 transition-colors">
                <ChevronLeft className="w-4 h-4" />
                Back to Tests
            </Link>

            <div className="max-w-2xl bg-white dark:bg-gray-900 rounded-lg shadow-lg p-8">
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Create Mock Test</h1>

                <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Test Name</label>
                        <input type="text" required className="input w-full border border-gray-300 rounded-lg px-4 py-2" placeholder="e.g. IBPS PO Prelims Mock 1" />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Duration (mins)</label>
                            <input type="number" required defaultValue={60} className="input w-full border border-gray-300 rounded-lg px-4 py-2" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Total Marks</label>
                            <input type="number" required defaultValue={100} className="input w-full border border-gray-300 rounded-lg px-4 py-2" />
                        </div>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Access Type</label>
                        <select className="input w-full border border-gray-300 rounded-lg px-4 py-2">
                            <option value="FREE">Free</option>
                            <option value="PAID">Premium (Paid)</option>
                        </select>
                    </div>

                    <div className="flex justify-end gap-3 pt-4">
                        <Link href="/admin/tests" className="btn btn-outline">Cancel</Link>
                        <button type="submit" disabled={loading} className="btn btn-primary flex items-center gap-2">
                            <Save className="w-4 h-4" />
                            {loading ? 'Saving...' : 'Create Test'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}
