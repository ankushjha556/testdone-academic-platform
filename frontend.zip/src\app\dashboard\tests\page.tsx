'use client';

import { useAuth } from '@/contexts/AuthContext';
import Link from 'next/link';
import { BookOpen, Calendar, Clock, BarChart2 } from 'lucide-react';

export default function MyTestsPage() {
    const { user } = useAuth();

    return (
        <div className="min-h-screen py-8 bg-gray-50 dark:bg-gray-950">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="mb-8">
                    <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">My Tests</h1>
                    <p className="text-gray-600 dark:text-gray-400">View your test history and performance.</p>
                </div>

                <div className="card p-8 text-center bg-white dark:bg-gray-900 shadow rounded-xl">
                    <div className="w-16 h-16 bg-primary-100 dark:bg-primary-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                        <BookOpen className="w-8 h-8 text-primary-600" />
                    </div>
                    <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">No Tests Attempted Yet</h2>
                    <p className="text-gray-500 mb-6 max-w-md mx-auto">
                        You haven't taken any mock tests yet. Start practicing today to improve your score!
                    </p>
                    <Link href="/tests" className="btn btn-primary">
                        Browse Mock Tests
                    </Link>
                </div>
            </div>
        </div>
    );
}
