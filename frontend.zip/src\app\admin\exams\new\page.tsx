'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { api } from '@/lib/api';
import { ChevronLeft, Save } from 'lucide-react';
import Link from 'next/link';

export default function CreateExamPage() {
    const router = useRouter();
    const [loading, setLoading] = useState(false);

    const [formData, setFormData] = useState({
        name: '',
        slug: '',
        description: '',
    });

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);

        try {
            const res = await api.post('/admin/exams', {
                ...formData,
                status: 'PUBLISHED' // Default to published for now
            });

            if (res.success) {
                router.push('/admin/exams');
            } else {
                alert('Failed to create exam: ' + (res.error?.message || 'Unknown error'));
            }
        } catch (error) {
            console.error(error);
            alert('An error occurred');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="p-8">
            <Link href="/admin/exams" className="flex items-center gap-2 text-gray-500 hover:text-gray-900 mb-6 transition-colors">
                <ChevronLeft className="w-4 h-4" />
                Back to Exams
            </Link>

            <div className="max-w-2xl bg-white dark:bg-gray-900 rounded-lg shadow-lg p-8">
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Create New Exam</h1>

                <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Exam Name</label>
                        <input
                            type="text"
                            required
                            className="input w-full border border-gray-300 rounded-lg px-4 py-2"
                            placeholder="e.g. IBPS PO 2024"
                            value={formData.name}
                            onChange={e => setFormData({ ...formData, name: e.target.value })}
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Slug (URL)</label>
                        <input
                            type="text"
                            required
                            className="input w-full border border-gray-300 rounded-lg px-4 py-2"
                            placeholder="e.g. ibps-po-2024"
                            value={formData.slug}
                            onChange={e => setFormData({ ...formData, slug: e.target.value })}
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Description</label>
                        <textarea
                            className="input w-full border border-gray-300 rounded-lg px-4 py-2 h-32"
                            placeholder="Exam details..."
                            value={formData.description}
                            onChange={e => setFormData({ ...formData, description: e.target.value })}
                        />
                    </div>

                    <div className="flex justify-end gap-3 pt-4">
                        <Link href="/admin/exams" className="btn btn-outline">Cancel</Link>
                        <button type="submit" disabled={loading} className="btn btn-primary flex items-center gap-2">
                            <Save className="w-4 h-4" />
                            {loading ? 'Saving...' : 'Create Exam'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}
