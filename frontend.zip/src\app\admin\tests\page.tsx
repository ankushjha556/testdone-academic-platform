'use client';

import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import Link from 'next/link';
import { Plus, Edit2, Trash2 } from 'lucide-react';

export default function AdminTestsPage() {
    const [tests, setTests] = useState<any[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        loadTests();
    }, []);

    const loadTests = async () => {
        try {
            const res = await api.get<{ tests: any[] }>('/admin/tests');
            if (res.success) {
                setTests(res.data?.tests || []);
            }
        } catch (error) {
            console.error('Failed to load tests', error);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="p-8">
            <div className="flex justify-between items-center mb-8">
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Mock Tests</h1>
                <Link href="/admin/tests/new" className="btn btn-primary flex items-center gap-2">
                    <Plus className="w-4 h-4" />
                    Create Test
                </Link>
            </div>

            <div className="card bg-white dark:bg-gray-900 shadow rounded-lg overflow-hidden">
                <table className="w-full text-left">
                    <thead className="bg-gray-50 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
                        <tr>
                            <th className="px-6 py-3 text-sm font-medium text-gray-500">Name</th>
                            <th className="px-6 py-3 text-sm font-medium text-gray-500">Exam</th>
                            <th className="px-6 py-3 text-sm font-medium text-gray-500">Access</th>
                            <th className="px-6 py-3 text-sm font-medium text-gray-500">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                        {isLoading ? (
                            <tr><td colSpan={4} className="p-6 text-center">Loading...</td></tr>
                        ) : tests.length === 0 ? (
                            <tr><td colSpan={4} className="p-6 text-center text-gray-500">No tests found.</td></tr>
                        ) : (
                            tests.map((test) => (
                                <tr key={test.id} className="hover:bg-gray-50 dark:hover:bg-gray-800">
                                    <td className="px-6 py-4">
                                        <div className="font-medium text-gray-900 dark:text-white">{test.name}</div>
                                        <div className="text-xs text-gray-500">{test.totalQuestions} Questions • {test.durationMinutes} mins</div>
                                    </td>
                                    <td className="px-6 py-4 text-gray-500">{test.exam?.name || '-'}</td>
                                    <td className="px-6 py-4">
                                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${test.accessType === 'FREE' ? 'bg-green-100 text-green-700' : 'bg-purple-100 text-purple-700'}`}>
                                            {test.accessType}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 flex gap-2">
                                        <button className="p-1 hover:text-primary-600"><Edit2 className="w-4 h-4" /></button>
                                        <button className="p-1 hover:text-red-600"><Trash2 className="w-4 h-4" /></button>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
