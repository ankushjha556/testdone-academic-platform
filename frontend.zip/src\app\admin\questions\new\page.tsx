'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { ChevronLeft, Save, Plus, Trash2 } from 'lucide-react';
import Link from 'next/link';

export default function CreateQuestionPage() {
    const router = useRouter();
    const [loading, setLoading] = useState(false);
    const [options, setOptions] = useState([
        { id: 'A', text: '', isCorrect: false },
        { id: 'B', text: '', isCorrect: false },
        { id: 'C', text: '', isCorrect: false },
        { id: 'D', text: '', isCorrect: false },
    ]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setTimeout(() => {
            setLoading(false);
            alert('Feature coming soon! Backend API integration required.');
            router.push('/admin/questions');
        }, 1000);
    };

    return (
        <div className="p-8">
            <Link href="/admin/questions" className="flex items-center gap-2 text-gray-500 hover:text-gray-900 mb-6 transition-colors">
                <ChevronLeft className="w-4 h-4" />
                Back to Questions
            </Link>

            <div className="max-w-4xl bg-white dark:bg-gray-900 rounded-lg shadow-lg p-8">
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Add New Question</h1>

                <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Question Text</label>
                        <textarea required className="input w-full border border-gray-300 rounded-lg px-4 py-2 h-32" placeholder="Enter question..." />
                    </div>

                    <div className="space-y-4">
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Options</label>
                        {options.map((opt, idx) => (
                            <div key={opt.id} className="flex items-center gap-3">
                                <div className="w-8 h-8 flex items-center justify-center font-bold bg-gray-100 rounded-full">
                                    {opt.id}
                                </div>
                                <input
                                    type="text"
                                    placeholder={`Option ${opt.id}`}
                                    className="flex-1 input border border-gray-300 rounded-lg px-4 py-2"
                                />
                                <input
                                    type="radio"
                                    name="correctOption"
                                    className="w-5 h-5 text-green-600 focus:ring-green-500"
                                    title="Mark as correct"
                                />
                            </div>
                        ))}
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Solution / Explanation</label>
                        <textarea className="input w-full border border-gray-300 rounded-lg px-4 py-2 h-24" placeholder="Detailed solution..." />
                    </div>

                    <div className="flex justify-end gap-3 pt-4">
                        <Link href="/admin/questions" className="btn btn-outline">Cancel</Link>
                        <button type="submit" disabled={loading} className="btn btn-primary flex items-center gap-2">
                            <Save className="w-4 h-4" />
                            {loading ? 'Saving...' : 'Save Question'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}
