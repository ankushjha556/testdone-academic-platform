'use client';

import { useAuth } from '@/contexts/AuthContext';
import Link from 'next/link';
import { Bookmark, BookOpen } from 'lucide-react';

export default function BookmarksPage() {
    return (
        <div className="min-h-screen py-8 bg-gray-50 dark:bg-gray-950">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="mb-8">
                    <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Bookmarks</h1>
                    <p className="text-gray-600 dark:text-gray-400">Your saved questions for review.</p>
                </div>

                <div className="card p-8 text-center bg-white dark:bg-gray-900 shadow rounded-xl">
                    <div className="w-16 h-16 bg-amber-100 dark:bg-amber-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Bookmark className="w-8 h-8 text-amber-600" />
                    </div>
                    <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">No Bookmarks Yet</h2>
                    <p className="text-gray-500 mb-6 max-w-md mx-auto">
                        You haven't bookmarked any questions. Review your test attempts or practice questions to find important topics.
                    </p>
                    <Link href="/questions" className="btn btn-primary">
                        Practice Questions
                    </Link>
                </div>
            </div>
        </div>
    );
}
