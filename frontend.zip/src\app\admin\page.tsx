'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from 'next/navigation';
import { api } from '@/lib/api';
import {
    Users,
    BookOpen,
    HelpCircle,
    ClipboardList,
    TrendingUp,
    CreditCard,
    Settings,
    LogOut,
    ChevronRight,
    Loader2,
    LayoutDashboard,
} from 'lucide-react';

interface DashboardStats {
    totalUsers: number;
    activeSubscriptions: number;
    todayRegistrations: number;
    totalTests: number;
    totalQuestions: number;
}

const sidebarItems = [
    { label: 'Dashboard', href: '/admin', icon: LayoutDashboard },
    { label: 'Exams', href: '/admin/exams', icon: BookOpen },
    { label: 'Questions', href: '/admin/questions', icon: HelpCircle },
    { label: 'Tests', href: '/admin/tests', icon: ClipboardList },
    { label: 'Users', href: '/admin/users', icon: Users },
    { label: 'Analytics', href: '/admin/analytics', icon: TrendingUp },
    { label: 'Settings', href: '/admin/settings', icon: Settings },
];

export default function AdminDashboard() {
    const { user, isLoading: authLoading, logout } = useAuth();
    const router = useRouter();
    const [stats, setStats] = useState<DashboardStats | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        if (!authLoading) {
            if (!user || !['SUPER_ADMIN', 'ADMIN', 'CONTENT_MANAGER'].includes(user.role)) {
                router.push('/login');
                return;
            }
            loadDashboard();
        }
    }, [user, authLoading]);

    const loadDashboard = async () => {
        try {
            const response = await api.get<DashboardStats>('/admin/dashboard');
            if (response.success) {
                setStats(response.data!);
            }
        } catch (error) {
            console.error('Failed to load dashboard:', error);
        } finally {
            setIsLoading(false);
        }
    };

    if (authLoading || isLoading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-100 dark:bg-gray-950">
                <Loader2 className="w-8 h-8 animate-spin text-primary-600" />
            </div>
        );
    }

    const statCards = [
        { label: 'Total Users', value: stats?.totalUsers || 0, icon: Users, color: 'blue' },
        { label: 'Active Subscriptions', value: stats?.activeSubscriptions || 0, icon: CreditCard, color: 'green' },
        { label: 'Today\'s Registrations', value: stats?.todayRegistrations || 0, icon: TrendingUp, color: 'amber' },
        { label: 'Published Tests', value: stats?.totalTests || 0, icon: ClipboardList, color: 'purple' },
        { label: 'Total Questions', value: stats?.totalQuestions || 0, icon: HelpCircle, color: 'pink' },
    ];

    return (
        <div className="min-h-screen bg-gray-100 dark:bg-gray-950 flex">
            {/* Sidebar */}
            <aside className="w-64 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-800 fixed h-full">
                <div className="p-4 border-b border-gray-200 dark:border-gray-800">
                    <Link href="/admin" className="flex items-center gap-2">
                        <div className="w-8 h-8 bg-gradient-to-br from-primary-500 to-primary-700 rounded-lg flex items-center justify-center">
                            <span className="text-white font-bold text-lg">T</span>
                        </div>
                        <span className="text-xl font-bold font-heading text-gray-900 dark:text-white">
                            Admin
                        </span>
                    </Link>
                </div>

                <nav className="p-4">
                    <ul className="space-y-1">
                        {sidebarItems.map((item) => (
                            <li key={item.href}>
                                <Link
                                    href={item.href}
                                    className="flex items-center gap-3 px-3 py-2 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                                >
                                    <item.icon className="w-5 h-5" />
                                    {item.label}
                                </Link>
                            </li>
                        ))}
                    </ul>
                </nav>

                <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-200 dark:border-gray-800">
                    <div className="flex items-center gap-3 mb-4">
                        <div className="w-10 h-10 bg-primary-100 dark:bg-primary-900/30 rounded-full flex items-center justify-center">
                            <span className="text-primary-600 font-medium">{user?.firstName?.charAt(0)}</span>
                        </div>
                        <div>
                            <p className="font-medium text-gray-900 dark:text-white text-sm">{user?.firstName}</p>
                            <p className="text-xs text-gray-500">{user?.role}</p>
                        </div>
                    </div>
                    <button
                        onClick={logout}
                        className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400 hover:text-red-600 transition-colors w-full"
                    >
                        <LogOut className="w-4 h-4" />
                        Logout
                    </button>
                </div>
            </aside>

            {/* Main Content */}
            <main className="flex-1 ml-64 p-8">
                <div className="mb-8">
                    <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Dashboard</h1>
                    <p className="text-gray-600 dark:text-gray-400">Welcome back! Here's your platform overview.</p>
                </div>

                {/* Stats Grid */}
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 mb-8">
                    {statCards.map((stat) => (
                        <div key={stat.label} className="card p-5">
                            <div className="flex items-center gap-3">
                                <div className={`w-10 h-10 rounded-lg flex items-center justify-center bg-${stat.color}-100 dark:bg-${stat.color}-900/30`}>
                                    <stat.icon className={`w-5 h-5 text-${stat.color}-600`} />
                                </div>
                                <div>
                                    <p className="text-2xl font-bold text-gray-900 dark:text-white">
                                        {stat.value.toLocaleString()}
                                    </p>
                                    <p className="text-sm text-gray-500">{stat.label}</p>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                {/* Quick Actions */}
                <div className="grid lg:grid-cols-2 gap-6">
                    <div className="card p-5">
                        <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Quick Actions</h2>
                        <div className="space-y-3">
                            <Link
                                href="/admin/questions/new"
                                className="flex items-center justify-between p-3 rounded-lg border border-gray-200 dark:border-gray-700 hover:border-primary-500 transition-colors"
                            >
                                <div className="flex items-center gap-3">
                                    <HelpCircle className="w-5 h-5 text-primary-600" />
                                    <span className="font-medium text-gray-900 dark:text-white">Add New Question</span>
                                </div>
                                <ChevronRight className="w-5 h-5 text-gray-400" />
                            </Link>
                            <Link
                                href="/admin/tests/new"
                                className="flex items-center justify-between p-3 rounded-lg border border-gray-200 dark:border-gray-700 hover:border-primary-500 transition-colors"
                            >
                                <div className="flex items-center gap-3">
                                    <ClipboardList className="w-5 h-5 text-green-600" />
                                    <span className="font-medium text-gray-900 dark:text-white">Create Mock Test</span>
                                </div>
                                <ChevronRight className="w-5 h-5 text-gray-400" />
                            </Link>
                            <Link
                                href="/admin/exams/new"
                                className="flex items-center justify-between p-3 rounded-lg border border-gray-200 dark:border-gray-700 hover:border-primary-500 transition-colors"
                            >
                                <div className="flex items-center gap-3">
                                    <BookOpen className="w-5 h-5 text-amber-600" />
                                    <span className="font-medium text-gray-900 dark:text-white">Add New Exam</span>
                                </div>
                                <ChevronRight className="w-5 h-5 text-gray-400" />
                            </Link>
                        </div>
                    </div>

                    <div className="card p-5">
                        <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Recent Activity</h2>
                        <div className="space-y-4">
                            {[
                                { action: 'New user registered', time: '5 mins ago' },
                                { action: 'Question approved', time: '12 mins ago' },
                                { action: 'Mock test created', time: '1 hour ago' },
                                { action: 'Premium subscription', time: '2 hours ago' },
                            ].map((activity, i) => (
                                <div key={i} className="flex items-center justify-between text-sm">
                                    <span className="text-gray-700 dark:text-gray-300">{activity.action}</span>
                                    <span className="text-gray-500">{activity.time}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
}
