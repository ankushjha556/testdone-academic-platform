import { Router } from 'express';
import prisma from '../lib/prisma';
import { authenticate, authorize, AuthRequest } from '../middleware/auth';
import { upload, getFileUrl } from '../lib/upload';

const router = Router();

// All admin routes require authentication and admin role
router.use(authenticate);
router.use(authorize('SUPER_ADMIN', 'ADMIN', 'CONTENT_MANAGER'));

// GET /api/v1/admin/dashboard
router.get('/dashboard', async (req: AuthRequest, res, next) => {
    try {
        const [
            totalUsers,
            activeSubscriptions,
            todayRegistrations,
            totalTests,
            totalQuestions,
        ] = await Promise.all([
            prisma.user.count(),
            prisma.subscription.count({ where: { status: 'ACTIVE' } }),
            prisma.user.count({
                where: {
                    createdAt: { gte: new Date(new Date().setHours(0, 0, 0, 0)) },
                },
            }),
            prisma.mockTest.count({ where: { status: 'PUBLISHED' } }),
            prisma.question.count({ where: { status: 'PUBLISHED' } }),
        ]);

        res.json({
            success: true,
            data: {
                totalUsers,
                activeSubscriptions,
                todayRegistrations,
                totalTests,
                totalQuestions,
            },
        });
    } catch (error) {
        next(error);
    }
});

// GET /api/v1/admin/stats - Alias for dashboard stats
router.get('/stats', async (req: AuthRequest, res, next) => {
    console.log('GET /admin/stats hit');
    try {
        const [
            totalUsers,
            activeSubscriptions,
            todayRegistrations,
            totalTests,
            totalQuestions,
            totalExams,
            totalSubjects
        ] = await Promise.all([
            prisma.user.count(),
            prisma.subscription.count({ where: { status: 'ACTIVE' } }),
            prisma.user.count({
                where: {
                    createdAt: { gte: new Date(new Date().setHours(0, 0, 0, 0)) },
                },
            }),
            prisma.mockTest.count(),
            prisma.question.count(),
            prisma.exam.count(),
            prisma.subject.count()
        ]);

        res.json({
            success: true,
            stats: { // Frontend expects "stats" key
                totalUsers,
                activeSubscriptions,
                todayRegistrations,
                totalTests,
                totalQuestions,
                totalExams,
                totalSubjects
            }
        });
    } catch (error) {
        next(error);
    }
});

// ============== CONTENT DROPDOWNS ==============

// GET /api/v1/admin/subjects
router.get('/subjects', async (req: AuthRequest, res, next) => {
    console.log('GET /admin/subjects hit');
    try {
        const subjects = await prisma.subject.findMany({
            orderBy: { order: 'asc' },
            select: { id: true, name: true, slug: true }
        });
        // Transform to DropdownItem[] format if needed, or sending raw objects
        // Frontend expects { data: { subjects: [...] } }
        res.json({ success: true, data: { subjects } });
    } catch (error) {
        next(error);
    }
});

// GET /api/v1/admin/subjects/:id/topics
router.get('/subjects/:id/topics', async (req: AuthRequest, res, next) => {
    try {
        const { id } = req.params;
        const topics = await prisma.topic.findMany({
            where: { subjectId: id },
            orderBy: { order: 'asc' },
            select: { id: true, name: true, slug: true }
        });
        res.json({ success: true, data: { topics } });
    } catch (error) {
        next(error);
    }
});

// ============== EXAM MANAGEMENT ==============

// GET /api/v1/admin/exams
router.get('/exams', async (req: AuthRequest, res, next) => {
    try {
        const { status, category, page = '1', limit = '20' } = req.query;
        const pageNum = parseInt(page as string, 10);
        const limitNum = parseInt(limit as string, 10);
        const skip = (pageNum - 1) * limitNum;

        const where: any = {};
        if (status) where.status = status;
        if (category) where.category = { slug: category };

        const [exams, total] = await Promise.all([
            prisma.exam.findMany({
                where,
                skip,
                take: limitNum,
                orderBy: { name: 'asc' },
                include: {
                    category: { select: { name: true } },
                    _count: { select: { mockTests: true, questionExams: true } },
                },
            }),
            prisma.exam.count({ where }),
        ]);

        res.json({
            success: true,
            data: { exams, pagination: { currentPage: pageNum, totalPages: Math.ceil(total / limitNum), totalItems: total } },
        });
    } catch (error) {
        next(error);
    }
});

// POST /api/v1/admin/exams
router.post('/exams', async (req: AuthRequest, res, next) => {
    try {
        const data = req.body;
        const exam = await prisma.exam.create({ data });
        res.status(201).json({ success: true, data: exam });
    } catch (error) {
        next(error);
    }
});

// PUT /api/v1/admin/exams/:id
router.put('/exams/:id', async (req: AuthRequest, res, next) => {
    try {
        const { id } = req.params;
        const exam = await prisma.exam.update({ where: { id }, data: req.body });
        res.json({ success: true, data: exam });
    } catch (error) {
        next(error);
    }
});

// DELETE /api/v1/admin/exams/:id
router.delete('/exams/:id', authorize('SUPER_ADMIN', 'ADMIN'), async (req: AuthRequest, res, next) => {
    try {
        const { id } = req.params;
        await prisma.exam.delete({ where: { id } });
        res.json({ success: true, message: 'Exam deleted' });
    } catch (error) {
        next(error);
    }
});

// GET /api/v1/admin/exams/categories - List exam categories
router.get('/exams/categories', async (req: AuthRequest, res, next) => {
    try {
        const categories = await prisma.examCategory.findMany({
            orderBy: { order: 'asc' },
            include: {
                _count: { select: { exams: true } }
            }
        });
        res.json({ success: true, data: { categories } });
    } catch (error) {
        next(error);
    }
});

// ============== QUESTION MANAGEMENT ==============

// GET /api/v1/admin/questions
router.get('/questions', async (req: AuthRequest, res, next) => {
    try {
        const { status, subject, difficulty, page = '1', limit = '20' } = req.query;
        const pageNum = parseInt(page as string, 10);
        const limitNum = parseInt(limit as string, 10);
        const skip = (pageNum - 1) * limitNum;

        const where: any = {};
        if (status) where.status = status;
        if (subject) where.subject = { slug: subject };
        if (difficulty) where.difficulty = difficulty;

        const [questions, total] = await Promise.all([
            prisma.question.findMany({
                where,
                skip,
                take: limitNum,
                orderBy: { createdAt: 'desc' },
                include: {
                    subject: { select: { name: true } },
                    topic: { select: { name: true } },
                    createdBy: { select: { firstName: true, lastName: true } },
                },
            }),
            prisma.question.count({ where }),
        ]);

        res.json({
            success: true,
            data: { questions, pagination: { currentPage: pageNum, totalPages: Math.ceil(total / limitNum), totalItems: total } },
        });
    } catch (error) {
        next(error);
    }
});

// POST /api/v1/admin/questions
router.post('/questions', async (req: AuthRequest, res, next) => {
    try {
        const data = { ...req.body, createdById: req.user!.id };
        const question = await prisma.question.create({ data });
        res.status(201).json({ success: true, data: question });
    } catch (error) {
        next(error);
    }
});

// PUT /api/v1/admin/questions/:id
router.put('/questions/:id', async (req: AuthRequest, res, next) => {
    try {
        const { id } = req.params;
        const question = await prisma.question.update({ where: { id }, data: req.body });
        res.json({ success: true, data: question });
    } catch (error) {
        next(error);
    }
});

// PATCH /api/v1/admin/questions/:id/status
router.patch('/questions/:id/status', async (req: AuthRequest, res, next) => {
    try {
        const { id } = req.params;
        const { status } = req.body;
        const question = await prisma.question.update({
            where: { id },
            data: {
                status,
                approvedById: status === 'APPROVED' ? req.user!.id : null,
            },
        });
        res.json({ success: true, data: question });
    } catch (error) {
        next(error);
    }
});

// ============== TEST MANAGEMENT ==============

// GET /api/v1/admin/tests
router.get('/tests', async (req: AuthRequest, res, next) => {
    try {
        const { status, exam, page = '1', limit = '20' } = req.query;
        const pageNum = parseInt(page as string, 10);
        const limitNum = parseInt(limit as string, 10);
        const skip = (pageNum - 1) * limitNum;

        const where: any = {};
        if (status) where.status = status;
        if (exam) where.exam = { slug: exam };

        const [tests, total] = await Promise.all([
            prisma.mockTest.findMany({
                where,
                skip,
                take: limitNum,
                orderBy: { createdAt: 'desc' },
                include: {
                    exam: { select: { name: true, slug: true } },
                    createdBy: { select: { firstName: true } },
                    _count: { select: { testQuestions: true, attempts: true } },
                },
            }),
            prisma.mockTest.count({ where }),
        ]);

        res.json({
            success: true,
            data: { tests, pagination: { currentPage: pageNum, totalPages: Math.ceil(total / limitNum), totalItems: total } },
        });
    } catch (error) {
        next(error);
    }
});

// POST /api/v1/admin/tests
router.post('/tests', async (req: AuthRequest, res, next) => {
    try {
        const { questions, ...testData } = req.body;

        const test = await prisma.mockTest.create({
            data: {
                ...testData,
                createdById: req.user!.id,
                testQuestions: {
                    create: questions?.map((q: any, i: number) => ({
                        questionId: q.questionId,
                        sectionIndex: q.sectionIndex || 0,
                        questionOrder: i + 1,
                        marks: q.marks || 1,
                    })) || [],
                },
            },
        });

        res.status(201).json({ success: true, data: test });
    } catch (error) {
        next(error);
    }
});

// PUT /api/v1/admin/tests/:id
router.put('/tests/:id', async (req: AuthRequest, res, next) => {
    try {
        const { id } = req.params;
        const { questions, ...testData } = req.body;

        // Update test data
        const test = await prisma.mockTest.update({
            where: { id },
            data: testData,
        });

        // If questions are provided, update them
        if (questions) {
            await prisma.testQuestion.deleteMany({ where: { testId: id } });
            await prisma.testQuestion.createMany({
                data: questions.map((q: any, i: number) => ({
                    testId: id,
                    questionId: q.questionId,
                    sectionIndex: q.sectionIndex || 0,
                    questionOrder: i + 1,
                    marks: q.marks || 1,
                })),
            });
        }

        res.json({ success: true, data: test });
    } catch (error) {
        next(error);
    }
});

// PATCH /api/v1/admin/tests/:id (partial update)
router.patch('/tests/:id', async (req: AuthRequest, res, next) => {
    try {
        const { id } = req.params;
        const test = await prisma.mockTest.update({ where: { id }, data: req.body });
        res.json({ success: true, data: test });
    } catch (error) {
        next(error);
    }
});

// DELETE /api/v1/admin/tests/:id
router.delete('/tests/:id', authorize('SUPER_ADMIN', 'ADMIN'), async (req: AuthRequest, res, next) => {
    try {
        const { id } = req.params;
        await prisma.mockTest.delete({ where: { id } });
        res.json({ success: true, message: 'Test deleted' });
    } catch (error) {
        next(error);
    }
});

// ============== SECTION MANAGEMENT ==============

// GET /api/v1/admin/exams/:examId/sections - Get sections for exam
router.get('/exams/:examId/sections', async (req: AuthRequest, res, next) => {
    try {
        const { examId } = req.params;
        const sections = await prisma.section.findMany({
            where: { examId },
            orderBy: { order: 'asc' },
            select: { id: true, name: true, slug: true, order: true, description: true }
        });
        res.json({ success: true, data: sections });
    } catch (error) {
        next(error);
    }
});

// POST /api/v1/admin/exams/:examId/sections - Create section
router.post('/exams/:examId/sections', async (req: AuthRequest, res, next) => {
    try {
        const { examId } = req.params;
        const { name, slug, description, order } = req.body;
        const section = await prisma.section.create({
            data: {
                name,
                slug: slug || name.toLowerCase().replace(/\s+/g, '-'),
                description,
                order: order || 0,
                examId
            }
        });
        res.status(201).json({ success: true, data: section });
    } catch (error) {
        next(error);
    }
});

// PUT /api/v1/admin/sections/:id - Update section
router.put('/sections/:id', async (req: AuthRequest, res, next) => {
    try {
        const { id } = req.params;
        const { name, slug, description, order } = req.body;
        const section = await prisma.section.update({
            where: { id },
            data: { name, slug, description, order }
        });
        res.json({ success: true, data: section });
    } catch (error) {
        next(error);
    }
});

// DELETE /api/v1/admin/sections/:id - Delete section
router.delete('/sections/:id', authorize('SUPER_ADMIN', 'ADMIN'), async (req: AuthRequest, res, next) => {
    try {
        const { id } = req.params;
        await prisma.section.delete({ where: { id } });
        res.json({ success: true, message: 'Section deleted' });
    } catch (error) {
        next(error);
    }
});

// ============== QUESTION CRUD - DELETE ==============

// DELETE /api/v1/admin/questions/:id
router.delete('/questions/:id', authorize('SUPER_ADMIN', 'ADMIN'), async (req: AuthRequest, res, next) => {
    try {
        const { id } = req.params;
        await prisma.question.delete({ where: { id } });
        res.json({ success: true, message: 'Question deleted' });
    } catch (error) {
        next(error);
    }
});

// ============== BOOK MANAGEMENT ==============

// GET /api/v1/admin/books
router.get('/books', async (req: AuthRequest, res, next) => {
    try {
        const { search, page = '1', limit = '20' } = req.query;
        const pageNum = parseInt(page as string, 10);
        const limitNum = parseInt(limit as string, 10);
        const skip = (pageNum - 1) * limitNum;

        const where: any = {};
        if (search) {
            where.OR = [
                { title: { contains: search as string, mode: 'insensitive' } },
                { author: { contains: search as string, mode: 'insensitive' } },
            ];
        }

        const [books, total] = await Promise.all([
            prisma.book.findMany({
                where,
                skip,
                take: limitNum,
                orderBy: { createdAt: 'desc' },
                select: {
                    id: true,
                    title: true,
                    author: true,
                    description: true,
                    coverUrl: true,
                    pdfUrl: true,
                    accessType: true,
                    createdAt: true,
                },
            }),
            prisma.book.count({ where }),
        ]);

        res.json({
            success: true,
            data: { books, pagination: { currentPage: pageNum, totalPages: Math.ceil(total / limitNum), totalItems: total } },
        });
    } catch (error) {
        next(error);
    }
});

// POST /admin/books - Create book with file upload
router.post('/books', upload.fields([{ name: 'pdf', maxCount: 1 }, { name: 'cover', maxCount: 1 }]), async (req: AuthRequest, res, next) => {
    try {
        const files = req.files as { pdf?: Express.Multer.File[], cover?: Express.Multer.File[] };
        const data = req.body;

        // Clean up empty strings for optional relations
        if (data.subjectId === '') data.subjectId = null;
        if (data.category === '') data.category = null;

        // Get file URLs
        const pdfUrl = files?.pdf?.[0] ? getFileUrl(req, files.pdf[0].path) : null;
        const coverUrl = files?.cover?.[0] ? getFileUrl(req, files.cover[0].path) : null;

        if (!pdfUrl) {
            return res.status(400).json({ success: false, error: { message: 'PDF file is required' } });
        }

        // Get file stats
        const fileStats = files.pdf?.[0];
        const sizeMb = fileStats ? (fileStats.size / (1024 * 1024)).toFixed(2) : '0';

        const book = await prisma.book.create({
            data: {
                ...data,
                pdfUrl,
                coverUrl: coverUrl || data.coverUrl || null,
                sizeMb: parseFloat(sizeMb),
            },
        });

        res.status(201).json({ success: true, data: book });
    } catch (error) {
        next(error);
    }
});

// PUT /api/v1/admin/books/:id
router.put('/books/:id', async (req: AuthRequest, res, next) => {
    try {
        const { id } = req.params;
        const book = await prisma.book.update({ where: { id }, data: req.body });
        res.json({ success: true, data: book });
    } catch (error) {
        next(error);
    }
});

// DELETE /api/v1/admin/books/:id
router.delete('/books/:id', authorize('SUPER_ADMIN', 'ADMIN'), async (req: AuthRequest, res, next) => {
    try {
        const { id } = req.params;
        await prisma.book.delete({ where: { id } });
        res.json({ success: true, message: 'Book deleted' });
    } catch (error) {
        next(error);
    }
});

// PATCH /api/v1/admin/exams/:id (partial update for status toggle)
router.patch('/exams/:id', async (req: AuthRequest, res, next) => {
    try {
        const { id } = req.params;
        const exam = await prisma.exam.update({ where: { id }, data: req.body });
        res.json({ success: true, data: exam });
    } catch (error) {
        next(error);
    }
});

// ============== USER MANAGEMENT ==============

// GET /api/v1/admin/users
router.get('/users', async (req: AuthRequest, res, next) => {
    try {
        const { role, search, page = '1', limit = '20' } = req.query;
        const pageNum = parseInt(page as string, 10);
        const limitNum = parseInt(limit as string, 10);
        const skip = (pageNum - 1) * limitNum;

        const where: any = {};
        if (role) where.role = role;
        if (search) {
            where.OR = [
                { firstName: { contains: search as string, mode: 'insensitive' } },
                { email: { contains: search as string, mode: 'insensitive' } },
            ];
        }

        const [users, total] = await Promise.all([
            prisma.user.findMany({
                where,
                skip,
                take: limitNum,
                orderBy: { createdAt: 'desc' },
                select: {
                    id: true,
                    email: true,
                    mobile: true,
                    firstName: true,
                    lastName: true,
                    role: true,
                    createdAt: true,
                    lastLoginAt: true,
                    _count: { select: { attempts: true } },
                },
            }),
            prisma.user.count({ where }),
        ]);

        res.json({
            success: true,
            data: { users, pagination: { currentPage: pageNum, totalPages: Math.ceil(total / limitNum), totalItems: total } },
        });
    } catch (error) {
        next(error);
    }
});

// PATCH /api/v1/admin/users/:id/role
router.patch('/users/:id/role', authorize('SUPER_ADMIN'), async (req: AuthRequest, res, next) => {
    try {
        const { id } = req.params;
        const { role } = req.body;
        const user = await prisma.user.update({ where: { id }, data: { role } });
        res.json({ success: true, data: user });
    } catch (error) {
        next(error);
    }
});

// DELETE /api/v1/admin/users/:id
router.delete('/users/:id', authorize('SUPER_ADMIN'), async (req: AuthRequest, res, next) => {
    try {
        const { id } = req.params;
        // Optional: Prevent deleting self
        if (id === req.user?.id) {
            return res.status(400).json({ success: false, error: { message: 'Cannot delete your own account' } });
        }
        await prisma.user.delete({ where: { id } });
        res.json({ success: true, message: 'User deleted' });
    } catch (error) {
        next(error);
    }
});

export default router;
