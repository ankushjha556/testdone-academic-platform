'use client';

import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import { BarChart3, Users, BookOpen, FileText } from 'lucide-react';

interface Stats {
    totalUsers: number;
    activeSubscriptions: number;
    todayRegistrations: number;
    totalTests: number;
    totalQuestions: number;
    totalExams: number;
    totalSubjects: number;
}

export default function AnalyticsPage() {
    const [stats, setStats] = useState<Stats | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadStats();
    }, []);

    const loadStats = async () => {
        try {
            setLoading(true);
            // Fixed: Use correct endpoint /admin/stats (not /admin/dashboard/stats)
            const res = await api.get<{ stats: Stats }>('/admin/stats');
            if (res.success && res.data) {
                // Backend returns { success: true, stats: {...} } - stats is nested in response
                const data = res.data as any;
                setStats(data.stats || data);
            }
        } catch (error) {
            console.error('Failed to load stats:', error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center min-h-screen">
                <div className="w-10 h-10 border-4 border-primary-500 border-t-transparent rounded-full animate-spin"></div>
            </div>
        );
    }

    return (
        <div className="p-8">
            <h1 className="text-3xl font-bold text-white mb-6">Analytics Dashboard</h1>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="card p-6">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-gray-400 text-sm">Total Users</p>
                            <p className="text-3xl font-bold text-white mt-2">{stats?.totalUsers || 0}</p>
                        </div>
                        <div className="w-12 h-12 bg-primary-500/20 rounded-lg flex items-center justify-center">
                            <Users className="w-6 h-6 text-primary-400" />
                        </div>
                    </div>
                </div>

                <div className="card p-6">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-gray-400 text-sm">Active Subscriptions</p>
                            <p className="text-3xl font-bold text-white mt-2">{stats?.activeSubscriptions || 0}</p>
                        </div>
                        <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
                            <BarChart3 className="w-6 h-6 text-green-400" />
                        </div>
                    </div>
                </div>

                <div className="card p-6">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-gray-400 text-sm">Total Exams</p>
                            <p className="text-3xl font-bold text-white mt-2">{stats?.totalExams || 0}</p>
                        </div>
                        <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                            <BookOpen className="w-6 h-6 text-blue-400" />
                        </div>
                    </div>
                </div>

                <div className="card p-6">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-gray-400 text-sm">Total Questions</p>
                            <p className="text-3xl font-bold text-white mt-2">{stats?.totalQuestions || 0}</p>
                        </div>
                        <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center">
                            <FileText className="w-6 h-6 text-purple-400" />
                        </div>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
                <div className="card p-6">
                    <h2 className="text-xl font-semibold text-white mb-4">Content Overview</h2>
                    <div className="space-y-4">
                        <div className="flex justify-between items-center">
                            <span className="text-gray-400">Mock Tests</span>
                            <span className="text-white font-semibold">{stats?.totalTests || 0}</span>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="text-gray-400">Subjects</span>
                            <span className="text-white font-semibold">{stats?.totalSubjects || 0}</span>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="text-gray-400">Today's Registrations</span>
                            <span className="text-white font-semibold">{stats?.todayRegistrations || 0}</span>
                        </div>
                    </div>
                </div>

                <div className="card p-6">
                    <h2 className="text-xl font-semibold text-white mb-4">Quick Stats</h2>
                    <div className="space-y-4">
                        <div className="flex justify-between items-center">
                            <span className="text-gray-400">Avg Questions per Exam</span>
                            <span className="text-white font-semibold">
                                {stats?.totalExams ? Math.round((stats.totalQuestions / stats.totalExams)) : 0}
                            </span>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="text-gray-400">Avg Tests per Exam</span>
                            <span className="text-white font-semibold">
                                {stats?.totalExams ? Math.round((stats.totalTests / stats.totalExams)) : 0}
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
