'use client';

import { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import Link from 'next/link';
import { api } from '@/lib/api';
import {
    ArrowLeft,
    Save,
    Upload,
    Loader2,
    Image as ImageIcon,
    X,
} from 'lucide-react';

interface ExamCategory {
    id: string;
    name: string;
}

interface ExamData {
    id: string;
    name: string;
    slug: string;
    fullName?: string;
    description?: string;
    eligibility?: string;
    syllabus?: any;
    conductingBody?: string;
    frequency?: string;
    vacancies?: string;
    salaryRange?: string;
    iconUrl?: string;
    isFeatured: boolean;
    status: string;
    categoryId: string;
    category: { id: string; name: string };
}

export default function ExamEditPage() {
    const router = useRouter();
    const params = useParams();
    const examId = params.id as string;

    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [uploading, setUploading] = useState(false);
    const [categories, setCategories] = useState<ExamCategory[]>([]);
    const [formData, setFormData] = useState({
        name: '',
        slug: '',
        fullName: '',
        description: '',
        eligibility: '',
        syllabus: {} as any,
        conductingBody: '',
        frequency: '',
        vacancies: '',
        salaryRange: '',
        iconUrl: '',
        isFeatured: false,
        status: 'DRAFT',
        categoryId: '',
    });

    useEffect(() => {
        loadData();
    }, [examId]);

    const loadData = async () => {
        try {
            const [examRes, catRes] = await Promise.all([
                api.get<ExamData>(`/admin/exams/${examId}`),
                api.get<{ categories: ExamCategory[] }>('/exams/categories'),
            ]);

            if (examRes.success && examRes.data) {
                const exam = examRes.data;
                setFormData({
                    name: exam.name || '',
                    slug: exam.slug || '',
                    fullName: exam.fullName || '',
                    description: exam.description || '',
                    eligibility: exam.eligibility || '',
                    syllabus: exam.syllabus || {},
                    conductingBody: exam.conductingBody || '',
                    frequency: exam.frequency || '',
                    vacancies: exam.vacancies || '',
                    salaryRange: exam.salaryRange || '',
                    iconUrl: exam.iconUrl || '',
                    isFeatured: exam.isFeatured || false,
                    status: exam.status || 'DRAFT',
                    categoryId: exam.categoryId || exam.category?.id || '',
                });
            }

            if (catRes.success && catRes.data?.categories) {
                setCategories(catRes.data.categories);
            }
        } catch (error) {
            console.error('Failed to load exam:', error);
            alert('Failed to load exam data');
        } finally {
            setLoading(false);
        }
    };

    const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        setUploading(true);
        try {
            const formDataUpload = new FormData();
            formDataUpload.append('file', file);
            formDataUpload.append('folder', 'testdone/exams');

            const res = await api.upload('/upload/image', formDataUpload);
            if (res.success && res.data && (res.data as any).url) {
                setFormData(prev => ({ ...prev, iconUrl: (res.data as any).url }));
            } else {
                alert('Failed to upload image');
            }
        } catch (error) {
            console.error('Upload error:', error);
            alert('Failed to upload image');
        } finally {
            setUploading(false);
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setSaving(true);

        try {
            const res = await api.put(`/admin/exams/${examId}`, formData);
            if (res.success) {
                alert('Exam updated successfully!');
                router.push('/admin/exams');
            } else {
                alert('Failed to update exam: ' + (res.error?.message || 'Unknown error'));
            }
        } catch (error) {
            console.error('Save error:', error);
            alert('Failed to save exam');
        } finally {
            setSaving(false);
        }
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center h-64">
                <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin"></div>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center gap-4">
                <Link
                    href="/admin/exams"
                    className="p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded-lg transition-colors"
                >
                    <ArrowLeft className="w-5 h-5" />
                </Link>
                <div>
                    <h1 className="text-2xl font-bold text-white">Edit Exam</h1>
                    <p className="text-gray-400">{formData.name}</p>
                </div>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid lg:grid-cols-3 gap-6">
                    {/* Main Content */}
                    <div className="lg:col-span-2 space-y-6">
                        {/* Basic Info */}
                        <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                            <h2 className="text-lg font-semibold text-white mb-4">Basic Information</h2>
                            <div className="grid sm:grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-300 mb-2">Name *</label>
                                    <input
                                        type="text"
                                        value={formData.name}
                                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                        className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-primary-500"
                                        required
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-300 mb-2">Slug</label>
                                    <input
                                        type="text"
                                        value={formData.slug}
                                        onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                                        className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-primary-500"
                                    />
                                </div>
                                <div className="sm:col-span-2">
                                    <label className="block text-sm font-medium text-gray-300 mb-2">Full Name</label>
                                    <input
                                        type="text"
                                        value={formData.fullName}
                                        onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                                        className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-primary-500"
                                        placeholder="e.g., Staff Selection Commission - Combined Graduate Level"
                                    />
                                </div>
                                <div className="sm:col-span-2">
                                    <label className="block text-sm font-medium text-gray-300 mb-2">Description</label>
                                    <textarea
                                        value={formData.description}
                                        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                                        rows={4}
                                        className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-primary-500"
                                    />
                                </div>
                            </div>
                        </div>

                        {/* Details */}
                        <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                            <h2 className="text-lg font-semibold text-white mb-4">Exam Details</h2>
                            <div className="grid sm:grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-300 mb-2">Conducting Body</label>
                                    <input
                                        type="text"
                                        value={formData.conductingBody}
                                        onChange={(e) => setFormData({ ...formData, conductingBody: e.target.value })}
                                        className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-primary-500"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-300 mb-2">Frequency</label>
                                    <input
                                        type="text"
                                        value={formData.frequency}
                                        onChange={(e) => setFormData({ ...formData, frequency: e.target.value })}
                                        className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-primary-500"
                                        placeholder="e.g., Yearly, Twice a year"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-300 mb-2">Vacancies</label>
                                    <input
                                        type="text"
                                        value={formData.vacancies}
                                        onChange={(e) => setFormData({ ...formData, vacancies: e.target.value })}
                                        className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-primary-500"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-300 mb-2">Salary Range</label>
                                    <input
                                        type="text"
                                        value={formData.salaryRange}
                                        onChange={(e) => setFormData({ ...formData, salaryRange: e.target.value })}
                                        className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-primary-500"
                                    />
                                </div>
                                <div className="sm:col-span-2">
                                    <label className="block text-sm font-medium text-gray-300 mb-2">Eligibility</label>
                                    <textarea
                                        value={formData.eligibility}
                                        onChange={(e) => setFormData({ ...formData, eligibility: e.target.value })}
                                        rows={3}
                                        className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-primary-500"
                                    />
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Sidebar */}
                    <div className="space-y-6">
                        {/* Publish */}
                        <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                            <h2 className="text-lg font-semibold text-white mb-4">Publish</h2>
                            <div className="space-y-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-300 mb-2">Status</label>
                                    <select
                                        value={formData.status}
                                        onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                                        className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-primary-500"
                                    >
                                        <option value="DRAFT">Draft</option>
                                        <option value="PUBLISHED">Published</option>
                                        <option value="ARCHIVED">Archived</option>
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-300 mb-2">Category</label>
                                    <select
                                        value={formData.categoryId}
                                        onChange={(e) => setFormData({ ...formData, categoryId: e.target.value })}
                                        className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-primary-500"
                                    >
                                        <option value="">Select Category</option>
                                        {categories.map(cat => (
                                            <option key={cat.id} value={cat.id}>{cat.name}</option>
                                        ))}
                                    </select>
                                </div>
                                <label className="flex items-center gap-3 cursor-pointer">
                                    <input
                                        type="checkbox"
                                        checked={formData.isFeatured}
                                        onChange={(e) => setFormData({ ...formData, isFeatured: e.target.checked })}
                                        className="w-5 h-5 rounded border-gray-600 bg-gray-800 text-primary-600 focus:ring-primary-500"
                                    />
                                    <span className="text-gray-300">Featured Exam</span>
                                </label>
                            </div>
                        </div>

                        {/* Image */}
                        <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                            <h2 className="text-lg font-semibold text-white mb-4">Icon/Image</h2>
                            <div className="space-y-4">
                                {formData.iconUrl ? (
                                    <div className="relative">
                                        <img
                                            src={formData.iconUrl}
                                            alt="Exam icon"
                                            className="w-full h-32 object-cover rounded-lg"
                                        />
                                        <button
                                            type="button"
                                            onClick={() => setFormData({ ...formData, iconUrl: '' })}
                                            className="absolute top-2 right-2 p-1 bg-red-600 text-white rounded-full hover:bg-red-700"
                                        >
                                            <X className="w-4 h-4" />
                                        </button>
                                    </div>
                                ) : (
                                    <label className="flex flex-col items-center justify-center h-32 border-2 border-dashed border-gray-700 rounded-lg cursor-pointer hover:border-gray-600 transition-colors">
                                        <input
                                            type="file"
                                            accept="image/*"
                                            onChange={handleImageUpload}
                                            className="hidden"
                                            disabled={uploading}
                                        />
                                        {uploading ? (
                                            <Loader2 className="w-8 h-8 text-gray-500 animate-spin" />
                                        ) : (
                                            <>
                                                <ImageIcon className="w-8 h-8 text-gray-500 mb-2" />
                                                <span className="text-sm text-gray-500">Upload Image</span>
                                            </>
                                        )}
                                    </label>
                                )}
                            </div>
                        </div>

                        {/* Syllabus */}
                        <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                            <h2 className="text-lg font-semibold text-white mb-4">Syllabus</h2>
                            <p className="text-sm text-gray-400 mb-4">
                                Structure: Stage (e.g., Tier-I) &rarr; Sections (e.g., General Intelligence).
                                Values are updated automatically.
                            </p>
                            <div className="space-y-6">
                                {Object.entries(formData.syllabus || {}).map(([stage, sections]: [string, any], stageIdx) => (
                                    <div key={stageIdx} className="border border-gray-700 rounded-lg p-4 bg-gray-800/50">
                                        <div className="flex justify-between items-center mb-4">
                                            <h3 className="font-medium text-white">{stage.replace('_', ' ')}</h3>
                                            <button
                                                type="button"
                                                onClick={() => {
                                                    const newSyllabus = { ...formData.syllabus };
                                                    delete newSyllabus[stage];
                                                    setFormData({ ...formData, syllabus: newSyllabus });
                                                }}
                                                className="text-red-400 hover:text-red-300 text-sm"
                                            >
                                                Remove Stage
                                            </button>
                                        </div>

                                        <div className="space-y-3 pl-4 border-l-2 border-gray-700">
                                            {Array.isArray(sections) && sections.map((section: any, secIdx: number) => (
                                                <div key={secIdx} className="flex gap-2 items-center">
                                                    <input
                                                        type="text"
                                                        placeholder="Section Name"
                                                        value={section.section}
                                                        onChange={(e) => {
                                                            const newSyllabus = { ...formData.syllabus };
                                                            newSyllabus[stage][secIdx].section = e.target.value;
                                                            setFormData({ ...formData, syllabus: newSyllabus });
                                                        }}
                                                        className="flex-1 px-3 py-1.5 bg-gray-900 border border-gray-700 rounded text-sm text-white"
                                                    />
                                                    <input
                                                        type="number"
                                                        placeholder="Qs"
                                                        value={section.questions}
                                                        onChange={(e) => {
                                                            const newSyllabus = { ...formData.syllabus };
                                                            newSyllabus[stage][secIdx].questions = parseInt(e.target.value) || 0;
                                                            setFormData({ ...formData, syllabus: newSyllabus });
                                                        }}
                                                        className="w-20 px-3 py-1.5 bg-gray-900 border border-gray-700 rounded text-sm text-white"
                                                    />
                                                    <input
                                                        type="number"
                                                        placeholder="Marks"
                                                        value={section.marks}
                                                        onChange={(e) => {
                                                            const newSyllabus = { ...formData.syllabus };
                                                            newSyllabus[stage][secIdx].marks = parseInt(e.target.value) || 0;
                                                            setFormData({ ...formData, syllabus: newSyllabus });
                                                        }}
                                                        className="w-20 px-3 py-1.5 bg-gray-900 border border-gray-700 rounded text-sm text-white"
                                                    />
                                                    <button
                                                        type="button"
                                                        onClick={() => {
                                                            const newSyllabus = { ...formData.syllabus };
                                                            newSyllabus[stage] = newSyllabus[stage].filter((_: any, i: number) => i !== secIdx);
                                                            setFormData({ ...formData, syllabus: newSyllabus });
                                                        }}
                                                        className="text-gray-500 hover:text-red-400"
                                                    >
                                                        <X className="w-4 h-4" />
                                                    </button>
                                                </div>
                                            ))}
                                            <button
                                                type="button"
                                                onClick={() => {
                                                    const newSyllabus = { ...formData.syllabus };
                                                    if (!newSyllabus[stage]) newSyllabus[stage] = [];
                                                    newSyllabus[stage].push({ section: '', questions: 0, marks: 0 });
                                                    setFormData({ ...formData, syllabus: newSyllabus });
                                                }}
                                                className="text-sm text-primary-400 hover:text-primary-300 flex items-center gap-1"
                                            >
                                                + Add Section
                                            </button>
                                        </div>
                                    </div>
                                ))}

                                <div className="flex gap-2">
                                    <input
                                        type="text"
                                        id="newStageName"
                                        placeholder="New Stage Name (e.g. Tier-1)"
                                        className="flex-1 px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white"
                                    />
                                    <button
                                        type="button"
                                        onClick={() => {
                                            const input = document.getElementById('newStageName') as HTMLInputElement;
                                            if (input.value) {
                                                const newSyllabus = { ...(formData.syllabus || {}) };
                                                newSyllabus[input.value] = [];
                                                setFormData({ ...formData, syllabus: newSyllabus });
                                                input.value = '';
                                            }
                                        }}
                                        className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded-lg"
                                    >
                                        Add Stage
                                    </button>
                                </div>
                            </div>
                        </div>

                        {/* Actions */}
                        <div className="flex gap-3">
                            <Link
                                href={`/admin/exams/${examId}/sections`}
                                className="flex-1 px-4 py-2.5 bg-gray-800 text-gray-300 rounded-lg hover:bg-gray-700 transition-colors text-center"
                            >
                                Sections
                            </Link>
                            <button
                                type="submit"
                                disabled={saving}
                                className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors disabled:opacity-50"
                            >
                                {saving ? (
                                    <Loader2 className="w-4 h-4 animate-spin" />
                                ) : (
                                    <Save className="w-4 h-4" />
                                )}
                                Save
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    );
}
