import { Metadata } from 'next';
import Link from 'next/link';
import { AlertCircle } from 'lucide-react';
import TestDetailContent from '@/components/test/TestDetailContent';

async function getTestData(slug: string) {
    try {
        const res = await fetch(`http://127.0.0.1:5000/api/v1/tests/${slug}`, { next: { revalidate: 3600 } });
        const data = await res.json();
        return data.success ? data.data : null;
    } catch (error) {
        return null;
    }
}

export async function generateMetadata({ params }: { params: { testId: string } }): Promise<Metadata> {
    const test = await getTestData(params.testId);

    if (!test) {
        return {
            title: 'Test Not Found | TestDone',
            description: 'The requested test could not be found.',
            robots: { index: false, follow: false },
        };
    }

    // Guardrail: NoIndex for private tests (if accessType is not FREE)
    // Actually, user said: "Only public tests should be indexable".
    // Assuming 'FREE' means public.
    if (test.accessType !== 'FREE') {
        return {
            title: `${test.name} - TestDone`,
            robots: { index: false, follow: false },
        };
    }

    return {
        title: `${test.name} - Online Mock Test (Free) | TestDone`,
        description: `Attempt ${test.name} online. Real exam interface, detailed solutions, and all-India rank. Improve your score with TestDone.`,
    };
}

export default async function TestDetailsPage({ params }: { params: { testId: string } }) {
    const test = await getTestData(params.testId);

    if (!test) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
                <div className="text-center">
                    <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
                    <h2 className="text-xl font-bold text-gray-900 mb-2">Error</h2>
                    <p className="text-gray-600 mb-6">Test not found</p>
                    <Link href="/tests" className="btn btn-secondary">
                        Browse All Tests
                    </Link>
                </div>
            </div>
        );
    }

    return <TestDetailContent test={test} />;
}
